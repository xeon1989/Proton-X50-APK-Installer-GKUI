#!/system/bin/sh
chmod +x /mnt/media_rw/udisk1/done.sh

SCRIPT_PATH="/mnt/media_rw/udisk1/done.sh"

. "$SCRIPT_PATH"